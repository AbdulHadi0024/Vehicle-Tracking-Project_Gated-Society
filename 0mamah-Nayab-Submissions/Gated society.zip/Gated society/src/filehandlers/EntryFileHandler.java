public class EntryFileHandler extends FileHandler {

    public void saveEntry(Entry entry) {
    }

    public List<Entry> getAllEntries() {
    }

    public Entry findById(String entryId) {
    }

    public List<Entry> findByVehicleNumber(
        String vehicleNumber) {
    }

    public void updateEntry(Entry updatedEntry) {
    }

    public List<Entry> getVehiclesInside() {
    }

    public List<Entry> getTodayEntries() {
    }
}