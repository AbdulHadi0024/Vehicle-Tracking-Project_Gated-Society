public class GateFileHandler extends FileHandler {

    public void saveGate(Gate gate) {
    }

    public List<Gate> getAllGates() {
    }

    public Gate findGateById(String gateId) {
    }

    public void updateGate(Gate gate) {
    }

    public boolean gateExists(String gateId) {
    }
}