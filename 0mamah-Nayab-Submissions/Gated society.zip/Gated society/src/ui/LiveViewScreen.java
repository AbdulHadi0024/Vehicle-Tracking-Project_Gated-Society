loadVehiclesInside();

refreshTable();

searchVehicle();

calculateDuration();

highlightOverstayVehicles();