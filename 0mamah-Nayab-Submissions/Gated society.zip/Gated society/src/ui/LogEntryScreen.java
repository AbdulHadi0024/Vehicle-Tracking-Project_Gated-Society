handleSubmitEntry();

validateEntryForm();

clearForm();

showSuccessMessage();

showErrorMessage();




entryService.logEntry(entry);