loadDashboardStatistics();

refreshDashboard();

openLogEntryScreen();

openLogExitScreen();

openLiveViewScreen();