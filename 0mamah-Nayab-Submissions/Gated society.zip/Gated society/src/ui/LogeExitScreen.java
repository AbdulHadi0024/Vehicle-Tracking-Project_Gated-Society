searchVehicle();

handleExit();

validateExitForm();

clearForm();