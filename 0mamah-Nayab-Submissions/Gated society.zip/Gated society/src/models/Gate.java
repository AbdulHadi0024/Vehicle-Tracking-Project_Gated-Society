
package com.gatesafe.model;

public class Gate {

    // Attributes
    private String gateId;
    private String gateName;
    private String location;
    private String status;

    // Default constructor
    public Gate() {
    }

    // Parameterized constructor
    public Gate(String gateId, String gateName,
                String location, String status) {

        this.gateId = gateId;
        this.gateName = gateName;
        this.location = location;
        this.status = status;
    }

    // Getters
    public String getGateId() {
        return gateId;
    }

    public String getGateName() {
        return gateName;
    }

    public String getLocation() {
        return location;
    }

    public String getStatus() {
        return status;
    }

    // Setters
    public void setGateName(String gateName) {
        this.gateName = gateName;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    @Override
    public String toString() {
        return "Gate ID: " + gateId +
               "\nGate Name: " + gateName +
               "\nLocation: " + location +
               "\nStatus: " + status;
    }
}
