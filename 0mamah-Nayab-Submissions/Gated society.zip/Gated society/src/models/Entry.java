
package com.gatesafe.model;

import java.time.LocalDateTime;

public class Entry {

    // 1. Attributes
    private String entryId;
    private String vehicleNumber;
    private String gateInId;
    private String gateOutId;
    private String guardId;
    private LocalDateTime entryTime;
    private LocalDateTime exitTime;
    private String status;

    // 2. Constructor
    public Entry() {
    }

    // 3. Parameterized constructor
    public Entry(String entryId,
                 String vehicleNumber,
                 String gateInId,
                 String guardId,
                 LocalDateTime entryTime) {

        this.entryId = entryId;
        this.vehicleNumber = vehicleNumber;
        this.gateInId = gateInId;
        this.guardId = guardId;
        this.entryTime = entryTime;

        this.status = "INSIDE";
    }

    // 4. Getters

    public String getEntryId() {
        return entryId;
    }

    public String getVehicleNumber() {
        return vehicleNumber;
    }

    public String getGateInId() {
        return gateInId;
    }

    public String getGateOutId() {
        return gateOutId;
    }

    public String getGuardId() {
        return guardId;
    }

    public LocalDateTime getEntryTime() {
        return entryTime;
    }

    public LocalDateTime getExitTime() {
        return exitTime;
    }

    public String getStatus() {
        return status;
    }

    // 5. Setters

    public void setGateOutId(String gateOutId) {
        this.gateOutId = gateOutId;
    }

    public void setExitTime(LocalDateTime exitTime) {
        this.exitTime = exitTime;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    // 6. Display information

    @Override
    public String toString() {

        return "Entry ID: " + entryId +
               "\nVehicle Number: " + vehicleNumber +
               "\nEntry Gate: " + gateInId +
               "\nExit Gate: " + gateOutId +
               "\nGuard ID: " + guardId +
               "\nEntry Time: " + entryTime +
               "\nExit Time: " + exitTime +
               "\nStatus: " + status;
    }
}
