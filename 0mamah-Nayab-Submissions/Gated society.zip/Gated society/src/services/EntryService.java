public class EntryService {

    public boolean logEntry(Entry entry) {
    }

    public boolean logExit(
        String vehicleNumber,
        String exitGateId) {
    }

    public List<Entry> getVehiclesInside() {
    }

    public List<Entry> getAllEntries() {
    }

    public Entry findActiveEntry(
        String vehicleNumber) {
    }

    public boolean isVehicleInside(
        String vehicleNumber) {
    }

    public List<Entry> getTodayEntries() {
    }

    public List<Entry> getOverstayVehicles(
        int allowedMinutes) {
    }

    public long getTodayEntryCount() {
    }

    public long getTodayExitCount() {
    }

    public long getCurrentInsideCount() {
    }
}