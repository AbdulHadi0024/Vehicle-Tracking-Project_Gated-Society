public class GateService {

    public boolean addGate(Gate gate) {
    }

    public boolean updateGate(Gate gate) {
    }

    public List<Gate> getAllGates() {
    }

    public Gate findGate(String gateId) {
    }

    public boolean isGateActive(String gateId) {
    }
}