import java.util.UUID;
public static String generateEntryId() {
    return "ENT-" +
        UUID.randomUUID().toString()
        .substring(0, 8).toUpperCase();
}