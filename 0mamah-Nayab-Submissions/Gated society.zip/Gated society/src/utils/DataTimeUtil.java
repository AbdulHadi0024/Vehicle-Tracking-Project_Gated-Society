import java.time.LocalDateTime;
import java.time.Duration;
import java.time.format.DateTimeFormatter;

public class DateTimeUtil {

    public static LocalDateTime getCurrentDateTime() {
    }

    public static long calculateDuration(
        LocalDateTime entryTime,
        LocalDateTime exitTime) {
    }

    public static boolean isOverstay(
        LocalDateTime entryTime,
        int allowedMinutes) {
    }

    public static String formatDateTime(
        LocalDateTime dateTime) {
    }

    public static String formatDuration(
        LocalDateTime entryTime,
        LocalDateTime exitTime) {
    }
}